Omega = 2;
hold on;
for (Xi = 0:0.2:2)
	disp(Xi)
	Sim = sim('../abc.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
end