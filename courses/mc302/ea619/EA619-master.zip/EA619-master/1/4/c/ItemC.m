Omega = 2;
Xi = 2;
Sim = sim('../abc.slx', 'ReturnWorkspaceOutputs', 'on');
plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);