hold on;
for (i = 1:25)
	disp(i)
	delta = 1/i;
	Sim = sim('d.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
end
