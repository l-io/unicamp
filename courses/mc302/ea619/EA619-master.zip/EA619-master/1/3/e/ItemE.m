hold on;
for (i = 1:10)
	disp(i)
	delta = 1/i;
	Sim = sim('e.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
end