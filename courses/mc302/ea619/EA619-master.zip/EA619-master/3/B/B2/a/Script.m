Param_pend;

for Theta0 = 0.1:0.3:pi-0.5
	Model = "pend_invertido.mdl";
	load_system(Model);
	set_param("pend_invertido/Integrator", "InitialCondition", num2str(Theta0));

	Sim = sim(Model, 'ReturnWorkspaceOutputs', 'on');
	Theta = Sim.yout(:, 1);
	X = Sim.tout;

	% plot(X, Theta);
	% title("θ x t");

	T = [];
	for I = 2:1:length(X)
		if (Theta(I) < 0 && Theta(I-1) >= 0)
			T = [T, X(I)];
		end
	end
	AveragePeriod = 0;
	for I = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(I)-T(I-1);
	end
	F = (length(T)-1)/AveragePeriod;
	S = sprintf("θ0: %f F: %f", Theta0, F);
	disp(S)
end