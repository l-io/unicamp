for lw2 = -0.07:0.001:-0.05
	Param_pend;
	
	Model = "pend_invertidoc.mdl";
	load_system(Model);
	
	set_param("pend_invertidoc/Integrator", "InitialCondition", num2str(0.0001));

	Sim = sim(Model, 'ReturnWorkspaceOutputs', 'on');
	Theta = Sim.yout(:, 1);
	X = Sim.tout;

	plot(X, Theta);
	title("θ x t");
	pause;

	T = [];
	for I = 2:1:length(X)
		if (Theta(I) < 0 && Theta(I-1) >= 0)
			T = [T, X(I)];
		end
	end
	AveragePeriod = 0;
	for I = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(I)-T(I-1);
	end
	F = (length(T)-1)/AveragePeriod;
	S = sprintf("lw2: %f F: %f", lw2, F);
	disp(S)
end