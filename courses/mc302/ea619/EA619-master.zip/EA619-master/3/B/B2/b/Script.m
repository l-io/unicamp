LW2 = [-0.15, -0.30, -0.50, -0.60];

for I = 1:1:length(LW2)
	lw2 = LW2(I);
	Param_pend;
	
	Model = "pend_invertidob.mdl";
	load_system(Model);
	
	set_param("pend_invertidob/Integrator", "InitialCondition", num2str(pi/8));

	Sim = sim(Model, 'ReturnWorkspaceOutputs', 'on');
	Theta = Sim.yout(:, 1);
	X = Sim.tout;

	% plot(X, Theta);
	% title("θ x t");

	T = [];
	for I = 2:1:length(X)
		if (Theta(I) < 0 && Theta(I-1) >= 0)
			T = [T, X(I)];
		end
	end
	AveragePeriod = 0;
	for I = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(I)-T(I-1);
	end
	F = (length(T)-1)/AveragePeriod;
	S = sprintf("lw2: %f F: %f", lw2, F);
	disp(S)
end