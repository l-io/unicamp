Param_pend;

Model = "pend_invertido.mdl";
load_system(Model);

Sim = sim(Model, 'ReturnWorkspaceOutputs', 'on');
plot(Sim.tout, wrapTo2Pi(Sim.yout(:, 1)));
title("θ x t");