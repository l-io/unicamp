load_system("Torque.slx");
hold on;

Delta = 1e-3;
Impulses = [pi/10, 10*pi/17, pi/10+10*pi/17];

X = [];
Y = [];
for I = 1:length(Impulses)
	Impulse = Impulses(I);
	
	subplot(4, 1, I);
	Sim = sim('Torque.slx', 'ReturnWorkspaceOutputs', 'on');
	X(I,:) = Sim.yout.get(1).Values.Time;
	Y(I,:) = wrapToPi(Sim.yout.get(1).Values.Data);
	plot(X(I,:), Y(I,:));
	
	T = [];
	for J = 2:1:length(X(I,:))
		if (Y(I,J) < 0 && Y(I,J-1) >= 0)
			T = [T, X(I,J)];
		end
	end
	AveragePeriod = 0;
	for J = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(J)-T(J-1);
	end
	if (isempty(T))
		title(char(I+96)+") T: "+num2str(Impulse));
	else
		F = (length(T)-1)/AveragePeriod;
		title(char(I+96)+") T: "+num2str(Impulse)+") F: "+num2str(F)+"Hz");
	end
end

subplot(4, 1, 4);
X = X(1,:);
Y = Y(1,:) + Y(2,:);
plot(X, Y);
title(char(1+96)+") + "+char(2+96)+") T: "+num2str(Impulses(1)+Impulses(2)));