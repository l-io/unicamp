Omega = [0, pi/10;
		0, 10*pi/17;
		0, -pi^2/5;
		pi, 0];

load_system("Pendulum.slx");
hold on;

for I = 1:length(Omega)
	O = Omega(I, 1);
	DO = Omega(I, 2);
	set_param("Pendulum/Integrator1", "InitialCondition", num2str(DO));
	set_param("Pendulum/Integrator2", "InitialCondition", num2str(O));
	
	subplot(2, 2, I);
	Sim = sim('Pendulum.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
	
	T = [];
	for J = 2:1:length(Sim.yout.get(1).Values.Time)
		if (Sim.yout.get(1).Values.Data(J) < 0 && Sim.yout.get(1).Values.Data(J-1) >= 0)
			T = [T, Sim.yout.get(1).Values.Time(J)];
		end
	end
	AveragePeriod = 0;
	for J = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(J)-T(J-1);
	end
	if (isempty(T))
		title(char(I+96)+") ("+num2str(O)+", "+num2str(DO)+")");
	else
		F = (length(T)-1)/AveragePeriod;
		title(char(I+96)+") ("+num2str(O)+", "+num2str(DO)+") F: "+num2str(F)+"Hz");
	end
end