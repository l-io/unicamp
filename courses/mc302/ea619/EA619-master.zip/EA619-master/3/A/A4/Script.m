load_system("Torque.slx");
hold on;

Delta = 1e-3;
Impulses = [pi/10, 10*pi/17];

for I = 1:length(Impulses)
	Impulse = Impulses(I);
	
	subplot(2, 1, I);
	Sim = sim('Torque.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
	
	T = [];
	for J = 2:1:length(Sim.yout.get(1).Values.Time)
		if (Sim.yout.get(1).Values.Data(J) < 0 && Sim.yout.get(1).Values.Data(J-1) >= 0)
			T = [T, Sim.yout.get(1).Values.Time(J)];
		end
	end
	AveragePeriod = 0;
	for J = 2:1:length(T)
		AveragePeriod = AveragePeriod + T(J)-T(J-1);
	end
	if (isempty(T))
		title(char(I+96)+") ("+num2str(O)+", "+num2str(DO)+")");
	else
		F = (length(T)-1)/AveragePeriod;
		title(char(I+96)+") ("+num2str(O)+", "+num2str(DO)+") F: "+num2str(F)+"Hz");
	end
end