%manipula("/home/renan/Desktop/EA619/5/Dados/SemPeso/5.47.txt", 5.47, 3, 4, "SemPeso.txt");
xid_11 = 0.0516;
xid_12 = 0.0598;
W_nd11 = 11.9385;
W_nd12 = 34.3960;
k_hw = 18.425446600012581;

SP = tf([k_hw*W_nd12^2], [1, 2*xid_12*W_nd12, W_nd12^2]);
CP = tf([k_hw*W_nd11^2], [1, 2*xid_11*W_nd11, W_nd11^2]);

%Sem Peso:
WrSP = 2*pi*5.200;
MpSP = 5.332e+01;
XiSP = sqrt(0.5 - sqrt(1-1/MpSP^2)/2);
WnSP = WrSP/sqrt(1-2*XiSP^2);

%Com Peso:
WrCP = 2*pi*1.860;
MpCP = 5.375e+01;
XiCP = sqrt(0.5 - sqrt(1-1/MpCP^2)/2);
WnCP = WrCP/sqrt(1-2*XiCP^2);

%5.4.2.3:
Jw = 0.0168;
J1 = Jw*WnCP^2/(WnSP^2-WnCP^2);
K1 = WnCP^2*(J1+Jw);
C1SP = 2*XiSP*WnSP*J1;