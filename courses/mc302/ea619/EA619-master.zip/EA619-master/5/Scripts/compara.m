format compact
disp('Entre com a fun��o de transfer�ncia do sistema,')
disp('ela j� deve estar dispon�vel utilizando o comando "tf",')
disp('verifique se o ensaio foi feito com ou sem controle.')
funtrans=input('Nome da fun��o de transfer�ncia pr�-definida   :> ');%,'s' );
arq=input('Nome do arquivo onde est�o os valores de freq��ncia (f), fase (fi),\n e rela��o de amplitudes (Ar) (extens�o .txt)   :> ','s' );
disp('Freq��ncias m�nima e m�xima para os diagramas de Bode.')
fmin=input('Entre com fmin na forma fmin=10^n1 [Hz]   :> ');
fmax=input('Entre com fmax na forma fmin=10^n2 [Hz]   :> ');
dados=load(arq);
f=dados(:,1);fi=dados(:,2);Ar=dados(:,3);

ArdB=20*log10(Ar);
[MAG,PHASE,W]=bode(funtrans,{2*pi*fmin,2*pi*fmax});
MAG=20*log10(MAG(:));

clf, 
subplot(2,1,1)
semilogx(f,ArdB,'ro'), hold on
semilogx(W/(2*pi),MAG(:)), grid
title('Medidas em Freqüência x Parâmetros da Resposta Temporal')
ylabel('Ar [dB]')
xlabel('Freqüência [Hz]')

subplot(2,1,2)
semilogx(f,fi,'ro'), hold on
semilogx(W/(2*pi),PHASE(:)), grid,
ylabel('Fase [grau]')
xlabel('Freqüência [Hz]')



