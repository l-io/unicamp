function manipula(arq1, f, ce, cs, arq2)
%arq1=input('Nome do arquivo com os dados (.txt)   :> ','s' );
a=load(arq1);
%f=input('Freq��ncia utilizada (em Hz)   :> ' );
%ce=input('Coluna de dados com o sinal de entrada   :> ' );
%cs=input('Coluna de dados com o sinal de sa�da   :> ' );
%arq2=input('Nome do arquivo para guardar a freq��ncia (f), a fase (fi),\n a rela��o de amplitudes (Ar), e a amplitude do sinais de sa�da (Bo)\n (extens�o .txt)   :> ','s' );
[fi,Ar,Bo]=defasagem(a,f,ce,cs)

fid=fopen(arq2,'at');
fprintf(fid,'\n%10.3f  %10.2f  %12.3e  %12.3e;',f,fi,Ar,Bo);
fclose(fid);
end