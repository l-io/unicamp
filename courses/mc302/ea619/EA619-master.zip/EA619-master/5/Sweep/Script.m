%With mass:
%Sweep result:
Fa = 1.8;
Fb = 2.0;
T = 5;
[WMax, Mp, XiCP] = Analyze("/home/renan/Desktop/EA619/5/Sweep/Dados/ComPeso/2.txt", Fa, Fb, T);
WrCP = 2*pi*WMax;
WnCP = WrCP/sqrt(1-2*XiCP^2);
TSMass = tf([WnCP^2], [1, 2*XiCP*WnCP, WnCP^2]);

WnCP = 11.687736180585301;
XiCP = 0.009302728122641;
TTMass = tf([WnCP^2], [1, 2*XiCP*WnCP, WnCP^2]);

%Without mass:
Fa = 4.75;
Fb = 6.25;
T = 10;
[WMax, Mp, XiSP] = Analyze("/home/renan/Desktop/EA619/5/Sweep/Dados/SemPeso/1.txt", Fa, Fb, T);
WrSP = 2*pi*WMax;
WnSP = WrSP/sqrt(1-2*XiSP^2);
TS = tf([WnSP^2], [1, 2*XiSP*WnSP, WnSP^2]);

WnSP = 32.675437277480867;
XiSP = 0.009377756695993;
TT = tf([WnSP^2], [1, 2*XiSP*WnSP, WnSP^2]);

%5.4.2.3:
Jw = 0.0168;
J1 = Jw*WnCP^2/(WnSP^2-WnCP^2);
K1 = WnCP^2*(J1+Jw);
C1SP = 2*XiSP*WnSP*J1;

%Time response result:
xid_11 = 0.00516;
xid_12 = 0.00598;
W_nd11 = 11.9385;
W_nd12 = 34.3960;
TTR = tf([W_nd12^2], [1, 2*xid_12*W_nd12, W_nd12^2]);
TTRMass = tf([W_nd11^2], [1, 2*xid_11*W_nd11, W_nd11^2]);

figure(1)
hold on;
Options = bodeoptions;
Options.FreqUnits = 'Hz';
bode(TS, 'k', {30, 37}, Options);
bode(TTR, 'b', {30, 37}, Options);
bode(TT, 'r:', {30, 37}, Options);
grid on;
hold off;

figure(2)
hold on;
Options = bodeoptions;
Options.FreqUnits = 'Hz';
bode(TSMass, 'k', {10, 13}, Options);
bode(TTRMass, 'b', {10, 13}, Options);
bode(TTMass, 'r:', {10, 13}, Options);
grid on;
hold off;