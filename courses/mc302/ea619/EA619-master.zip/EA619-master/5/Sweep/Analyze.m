function [FMax, Mp, Xi] = Analyze(Path, Fa, Fb, Time)
	%Get input from file:
	File = csvread(Path);

	%Get complete time vector:
	T = File(:, 2);
	I = floor(length(T)*Fa/Fb);

	%Obtain input frequency, input and output vectors:
	F = (Fb-Fa)*(T(I:end)-T(I))/Time + Fa;
	X = File(I:end, 3);
	Y = File(I:end, 4);

	%Remove DC components:
	X = X - mean(X);
	Y = Y - mean(Y);

	%Find peaks:
	XAmplitude = mean(findpeaks(X));
	[Py, IP] = findpeaks(abs(Y)/XAmplitude);
	[MaxY, IMax] = max(abs(Y));

	FMax = F(IMax);
	Mp = MaxY/XAmplitude;
	Xi = sqrt((1 - sqrt(1-1/Mp^2))/2);
end