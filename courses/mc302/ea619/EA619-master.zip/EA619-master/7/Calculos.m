%Temporal Sem Massa Extra:
M1 = 0.2;
YEnd1 = 0.1409;
X1 = [0.13, 0.33, 0.535, 0.73];
Y1 = [0.1978, 0.153, 0.1434, 0.1414] - YEnd1;

T1 = mean(X1(2:end)-X1(1:end-1));
Wd1 = 2*pi/T1;
Xi1 = mean(log(Y1(1:end-1)./Y1(2:end))/(2*pi));
Wn1 = Wd1/sqrt(1-Xi1^2);
Wr1 = Wn1/sqrt(1-2*Xi1^2);

fprintf("Temporal:\n\t1: Sem Massa Extra: T = %f\tXi = %f\tWd = %f\tWn = %f\tWr = %f\n", T1, Xi1, Wd1, Wn1, Wr1);

%Temporal Com Massa Extra:
M2 = 0.3;
YEnd2 = 0.136;
X2 = [0.17, 0.42, 0.66, 0.905];
Y2 = [0.1924, 0.1516, 0.1404, 0.1372] - YEnd2;

T2 = mean(X2(2:end)-X2(1:end-1));
Wd2 = 2*pi/T2;
Xi2 = mean(log(Y2(1:end-1)./Y2(2:end))/(2*pi));
Wn2 = Wd2/sqrt(1-Xi2^2);
Wr2 = Wn2/sqrt(1-2*Xi2^2);

fprintf("\t2: Com Massa Extra: T = %f\tXi = %f\tWd = %f\tWn = %f\tWr = %f\n", T2, Xi2, Wd2, Wn2, Wr2);

%Estimativa de constante de mola:
g = 9.8;
k = g*(M2-M1)/(YEnd1-YEnd2);

Ma = M2-M1;
M = Wd2^2*Ma/(Wd1^2-Wd2^2);
k = Wd1^2*M;
c = 2*Xi1*sqrt(M*k);
fprintf("\tParâmetros:\tm = %f\tk = %f\tc = %f\n", M, k, c);
kn = 203;
cn = 3;
fprintf("\t\t\tem = %f%%\tek = %f%%\tec = %f%%\n", 100*((M/M1)-1), 100*((k/kn)-1), 100*((c/cn)-1));

%Frequencial Sem Massa Extra:
AMax1 = 0.0105365;
HDC = 0.0049;
Mp1 = AMax1 / HDC;
Wr1 = 30.6;
Xi1 = sqrt((1-sqrt(1-1/Mp1^2))/2);
Wn1 = Wr1/sqrt(1-2*Xi1^2);
Wd1 = Wn1/sqrt(1-Xi1^2);

fprintf("Frequencial:\n\t1: Sem Massa Extra: Mp = %f\tXi = %f\tWd = %f\tWn = %f\n", Mp1, Xi1, Wd1, Wn1);

%Frequencial Com Massa Extra:
AMax2 = 0.012845616787672;
HDC = 0.0049;
Mp2 = AMax2 / HDC;
Wr2 = 25.5;
Xi2 = sqrt((1-sqrt(1-1/Mp2^2))/2);
Wn2 = Wr2/sqrt(1-2*Xi2^2);
Wd2 = Wn2/sqrt(1-Xi2^2);

fprintf("\t2: Com Massa Extra: Mp = %f\tXi = %f\tWd = %f\tWn = %f\n", Mp2, Xi2, Wd2, Wn2);

Ma = M2-M1;
M = Wd2^2*Ma/(Wd1^2-Wd2^2);
k = Wd1^2*M;
c = 2*Xi1*sqrt(M*k);
fprintf("\tParâmetros:\tm = %f\tk = %f\tc = %f\n", M, k, c);
kn = 203;
cn = 3;
fprintf("\t\t\tem = %f%%\tek = %f%%\tec = %f%%\n", 100*((M/M1)-1), 100*((k/kn)-1), 100*((c/cn)-1));

