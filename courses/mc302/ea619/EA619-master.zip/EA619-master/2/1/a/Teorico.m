Xi = 0.5;
T = sprintf("Xi\t\tOmega\t\tMp\t\tTp", Omega, Mp, Tp);
disp(T);
for (Omega = 0.5:0.5:2)
	Mp = exp(-Xi*pi/sqrt(1-Xi^2));
	Tp = pi/Omega/sqrt(1-Xi^2);
	T = sprintf("%f\t%f\t%f\t%f", Xi, Omega, Mp, Tp);
	disp(T);
end
