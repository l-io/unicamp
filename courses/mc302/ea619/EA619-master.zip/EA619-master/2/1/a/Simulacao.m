Xi = 0.5;
hold on;
for (Omega = 0.5:0.5:2)
	disp(Xi);
	Sim = sim('../Diagrama.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
end
