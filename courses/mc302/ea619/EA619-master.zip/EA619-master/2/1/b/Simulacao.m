T = sprintf("Xi\t\tTp\t\tOmegaN\t\tWn\t\tWd");
disp(T);
Xi = 0.5;
hold on;
for (Omega = 0.5:0.5:2)
	Sim = sim('../Diagrama.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);
	[Ymax, Xmax] = max(Sim.yout.get(1).Values.Data);
	
	Tp = Sim.tout(Xmax);
	OmegaNGrafico = pi/(Tp*sqrt(1-Xi^2));
	OmegaDGrafico = pi/Tp;

	T = sprintf("%f\t%f\t%f\t%f\t%f", Xi, Tp, Omega, OmegaNGrafico, OmegaDGrafico);
	disp(T);
end
