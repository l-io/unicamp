Xi = 0.5;
T = sprintf("Xi\t\tOmega\t\tTp");
disp(T);
for (Omega = 0.5:0.5:2)
	Tp = pi/Omega/sqrt(1-Xi^2);
	T = sprintf("%f\t%f\t%f\t%f", Xi, Omega, Tp);
	disp(T);
end
