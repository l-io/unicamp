T = sprintf("Xi\t\tOmega\t\tMp\t\tTp\t\tXiG\t\tWnG\t\tWdG\t\tPolos");
disp(T);
Xi = 0.5;
hold on;
for (Omega = 0.5:0.5:2)
	Sim = sim('../Diagrama.slx', 'ReturnWorkspaceOutputs', 'on');
	plot(Sim.yout.get(1).Values.Time, Sim.yout.get(1).Values.Data);

	[Mp, Mpx] = max(Sim.yout.get(1).Values.Data);
	Tp = Sim.tout(Mpx);
	XiGrafico = sqrt(log(Mp-1)^2/(pi^2+log(Mp-1)^2));
	OmegaNGrafico = pi/(Tp*sqrt(1-XiGrafico^2));
	OmegaDGrafico = pi/Tp;
	P = [1, 2*Xi*Omega, Omega^2];
	R = roots(P);
	T = sprintf("%f\t%f\t%f\t%f\t%f\t%f\t%f\t(s-(%f+%fi))\t(s-(%f+%fi))", Xi, Omega, Mp, Tp, XiGrafico, OmegaNGrafico, OmegaDGrafico, real(R(1)), imag(R(1)), real(R(2)), imag(R(2)));
	disp(T);
end
