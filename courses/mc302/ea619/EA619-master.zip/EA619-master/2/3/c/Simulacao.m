m1 = 0.7;
m2 = 0.5;
k1 = 380;
k2 = 200;
k3 = k1;
c1 = 1.5;
c2 = c1;
delta = 1/1000;

Sim = sim('../Sistema.slx', 'ReturnWorkspaceOutputs', 'on');
T = Sim.tout;
X1 = Sim.yout.get(1).Values.Data;
dX1 = Sim.yout.get(3).Values.Data;
X2 = Sim.yout.get(2).Values.Data;
dX2 = Sim.yout.get(4).Values.Data;

plot(X1, X2);
title('x1(t) vs x2(t)');
grid;