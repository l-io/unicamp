Dados = plotRawData("Data4.txt");
X = Dados.tempo;
Y = Dados.var(:,1);

dY = lowpass(gradient(Y)./gradient(X), 0.01);

%Rising part:
A1 = find(X == 0.089);
A2 = find(X == 0.416);

%Falling part:
B1 = find(X == 1.116);
B2 = find(X == 1.364);

%Item 3:
plot(X, dY);

F1 = polyfit(X(A1:A2), dY(A1:A2), 1);
F2 = polyfit(X(B1:B2), dY(B1:B2), 1);

%Item 4:
A = (abs(F1(1)) + abs(F2(1)))/2;

%Item 5:
J_d1 = 0.002302856741853;
J_m = 0.016812562500000;
J1 = J_d1 + J_m;

k_s = 32;
k_c = 10/32768;
k_hw = k_s * k_c * J1 * A;

%Item 6:
Delta = 1e-2;
Torque = 200;
c1 = 0.002839288625943;
k1 = 2.724469109795308;

Sim = sim("6/Diagrama.slx", "ReturnWorkspaceOutputs", "on");
X = Sim.yout.get(1).Values.Time;
Y = (Sim.yout.get(1).Values.Data);

plot(X, Y);
title("\theta_1 x t");
