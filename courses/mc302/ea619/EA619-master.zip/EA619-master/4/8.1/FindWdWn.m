function [Wd, Wn, Xi] = FindWdWn(File, Cut)
	Dados = plotRawData(File);
	X = Dados.tempo;
	Y = Dados.var(:, 1);

	Equilibrio = mean(Y(round(Cut*length(Y)):end));

	[Picos, Indices] = findpeaks(Y);
	Indices = Indices(2:end);
	Picos = Picos(2:end)-Equilibrio;

	Ts = [];
	Sum = 0;
	N = 0;
	for I = 1:1:0.5*length(Picos)-1
		if (Picos(I) <= 500 && Picos(I) >= 100)
			Sum = Sum + (Picos(I)-Equilibrio)/(Picos(I+1)-Equilibrio);
			N = N + 1;
			Ts = [Ts, X(Indices(I))];
		end
	end

	A = (log(Sum/N)/(2*pi))^2;
	Xi = sqrt(A/(1+A));

	%Item 6:
	plot(X(1:round(Cut*length(Y))), Y(1:round(Cut*length(Y))));

	%Item 7:
	Wd = 2*pi/mean(diff(Ts));
	Wn = Wd/sqrt(1-Xi^2);
end