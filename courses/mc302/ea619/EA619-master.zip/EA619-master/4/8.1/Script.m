%Itens 6-10:
[W_dd11, W_nd11, Xi_d11] = FindWdWn("6-9/D11/Data1.txt", 0.75);
[W_dd12, W_nd12, Xi_d12] = FindWdWn("6-9/D12/Data2.txt", 0.3);
[W_dd13, W_nd13, Xi_d13] = FindWdWn("6-9/D13/Data3.txt", 0.60);

%Item 11:
r = 4.95/200;
dr = 0.02/200;
d = 9.0/100;
dd = 0.1/100;
m = 500/1000;
dm = 5/1000;

J_w = m*d^2 + 0.5*m*r^2;
dJ_w = 0.5*sqrt(4*d^4*dm^2 + d^2*(16*dd^2*m^2 + 4*dm^2*r^2) + r^2*(4*m^2*dr^2 + dm^2*r^2));

%Item 12:
J_m = 4*J_w;
dJ_m = 4*dJ_w;
J_d1 = (W_nd11^2 * J_m)/(W_nd12^2 - W_nd11^2);
k_d1 = W_nd12^2 * J_d1
c_d1 = 2*Xi_d11*W_nd11*J_d1
J = J_m + J_d1;

%Item 13:
J_d3 = (W_nd13^2 * (J_m + J_d1))/(W_nd12^2 - W_nd13^2);
k_d3 = W_nd12^2 * J_d3;
c_d3 = 2*Xi_d13*W_nd13*J_d3;