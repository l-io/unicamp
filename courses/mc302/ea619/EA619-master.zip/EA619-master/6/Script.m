format long;

%8.2.1.2:
c1 = 0.0076394;
J1 = 0.0187;
khw = 17.6;

wn = [3, 4, 12];
kp = (J1*wn.^2)/khw;
kd = (J1*wn-c1)/khw;

%Gráficos:
Ganho = 100;

Dados1 = plotRawData("Dados/fun1/kpd-3/tor11.txt", [1, 2, 3]);
Dados2 = plotRawData("Dados/fun1/kpd-3/tor12.txt", [1, 2, 3]);
T = Dados1.tempo;
X1 = Dados1.var(:, 1);
Y1 = Dados1.var(:, 2);
Y2 = Dados2.var(:, 2);

X1(X1 == 0) = NaN;

hold on;
stem(T, X1);
plot(T, Ganho*Y1, "k", T, Ganho*Y2, "b");
hold off;
title("Resposta vs posição comandada")
xlabel("Tempo");
ylabel("Posição");