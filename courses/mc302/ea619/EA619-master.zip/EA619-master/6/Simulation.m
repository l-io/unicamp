J = 1;
Delta = 0.1;
Xi = 0.5;
A = 1;

%Diagrama 5:
Wss = [25, 25, 4, 4];
Wns = [6, 3, 3, 6];

for I = 1:1:length(Wss)
	Ws = Wss(I);
	Wn = Wns(I);

	Sim = sim("Diagram5.slx", "ReturnWorkspaceOutputs", "on");
	T = Sim.tout;
	Y = Sim.yout.get(1).Values.Data;
	Ys = Sim.yout.get(2).Values.Data;
	Yf = Sim.yout.get(3).Values.Data;
	figure(J);
	J = J+1;
	title("ω_s = " + num2str(Ws) + " rad/s ω_n = " + num2str(Wn) + " rad/s");
	subplot(3, 1, 1);
	plot(T, Y);
	title("Y x T");
	ylabel("Y");
	xlabel("T[s]");
	subplot(3, 1, 2);
	Ys(Ys == 0) = NaN;
	stem(T, Ys);
	title("Y* x T");
	ylabel("Y*");
	xlabel("T[s]");
	subplot(3, 1, 3);
	plot(T, Yf);
	title("Yf x T");
	ylabel("Yf");
	xlabel("T[s]");
end

%Diagrama 7:
Wss = [150, 150, 150];
Wns = [12, 3, 50];
for I = 1:1:length(Wss)
	Ws = Wss(I);
	Wn = Wns(I);

	Sim = sim("Diagram7.slx", "ReturnWorkspaceOutputs", "on");
	T = Sim.tout;
	Y = Sim.yout.get(1).Values.Data;
	Ys = Sim.yout.get(2).Values.Data;
	Yf = Sim.yout.get(3).Values.Data;
	figure(J);
	J = J+1;
	title("ω_s = " + num2str(Ws) + " rad/s ω_n = " + num2str(Wn) + " rad/s");
	subplot(3, 1, 1);
	plot(T, Y);
	title("Y x T");
	ylabel("Y");
	xlabel("T[s]");
	subplot(3, 1, 2);
	Ys(Ys == 0) = NaN;
	stem(T, Ys);
	title("Y* x T");
	ylabel("Y*");
	xlabel("T[s]");
	subplot(3, 1, 3);
	plot(T, Yf);
	title("Yf x T");
	ylabel("Yf");
	xlabel("T[s]");
end
