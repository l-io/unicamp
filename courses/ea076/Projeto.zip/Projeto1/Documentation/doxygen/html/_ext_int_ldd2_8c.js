var _ext_int_ldd2_8c =
[
    [ "ExtIntLdd2_TDeviceDataPtr", "_ext_int_ldd2_8c.html#gabbf18af683c9514a051ae7f753a1c184", null ],
    [ "ExtIntLdd2_GetVal", "_ext_int_ldd2_8c.html#ga1a934e0fb480b3596d9b57963fd974d3", null ],
    [ "ExtIntLdd2_Init", "_ext_int_ldd2_8c.html#ga633f6e55098bd97e0801091d4981fc98", null ],
    [ "ExtIntLdd2_Interrupt", "_ext_int_ldd2_8c.html#ga374b6255e964dbd64f42197e1619ff01", null ]
];