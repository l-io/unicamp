var _ext_int_ldd2 =
[
    [ "Component Settings", "_ext_int_ldd2_settings.html", null ],
    [ "Registers Initialization Overview", "_ext_int_ldd2_regs_overview.html", null ],
    [ "Register Initialization Details", "_ext_int_ldd2_regs_details.html", null ]
];