var _events_8h =
[
    [ "C1_OnInterrupt", "_events_8h.html#ga58156bc0de5d485e4148891f6188f998", null ],
    [ "C2_OnInterrupt", "_events_8h.html#ga3366e31481821b88971f3b76ef44f925", null ],
    [ "C3_OnInterrupt", "_events_8h.html#gad69956376a2f9c6ccb90f0b84f833c79", null ],
    [ "Cpu_OnNMIINT", "_events_8h.html#ga960d094664356278ac5472d45a6ea2f3", null ],
    [ "ESP_OnError", "_events_8h.html#ga23d383b5b2bd33fc136d5ab32f167f2e", null ],
    [ "ESP_OnRxChar", "_events_8h.html#ga097c764a6df10eb9eb2fcb54a313a41e", null ],
    [ "ESP_OnTxChar", "_events_8h.html#ga78dd0882d67a352b9e3e215d78fd5aee", null ],
    [ "Hall_OnCalibrationEnd", "_events_8h.html#gaad1f7460b06656280e724090108e5c02", null ],
    [ "Hall_OnEnd", "_events_8h.html#ga077fd05e9eeb2c5ef355de9dac11a446", null ],
    [ "PC_OnError", "_events_8h.html#gada03f4e4cf41102bf56866c746901e29", null ],
    [ "PC_OnRxChar", "_events_8h.html#ga0d96079f8443f826ca337082c11cbf0e", null ],
    [ "PC_OnTxChar", "_events_8h.html#ga42c2301bbc18b640df524d436d00f6e2", null ],
    [ "RTC1_OnSecond", "_events_8h.html#ga2f94110e651cb30cba928647e91e92d4", null ]
];