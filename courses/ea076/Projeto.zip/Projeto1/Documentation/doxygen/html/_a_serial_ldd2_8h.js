var _a_serial_ldd2_8h =
[
    [ "ASerialLdd2_GetError_METHOD_ENABLED", "_a_serial_ldd2_8h.html#gad0d7256dc7800d335b9bb2122ae19459", null ],
    [ "ASerialLdd2_Init_METHOD_ENABLED", "_a_serial_ldd2_8h.html#ga0733c5676cb9059befd74a42eec355a1", null ],
    [ "ASerialLdd2_OnBlockReceived_EVENT_ENABLED", "_a_serial_ldd2_8h.html#ga1de13d2017cc0ef844acf2c461975589", null ],
    [ "ASerialLdd2_OnBlockSent_EVENT_ENABLED", "_a_serial_ldd2_8h.html#ga7dfcea605c62f020478dd3d4cbf9beb1", null ],
    [ "ASerialLdd2_OnBreak_EVENT_ENABLED", "_a_serial_ldd2_8h.html#ga975445b42dc0a4fc37d8683c75c73287", null ],
    [ "ASerialLdd2_OnError_EVENT_ENABLED", "_a_serial_ldd2_8h.html#gadba446a2ac10bec7ef67f2dae167bc86", null ],
    [ "ASerialLdd2_PRPH_BASE_ADDRESS", "_a_serial_ldd2_8h.html#ga0b40933a9f68fae4f6112ed9a6cfd9ef", null ],
    [ "ASerialLdd2_ReceiveBlock_METHOD_ENABLED", "_a_serial_ldd2_8h.html#gada8358a92a4e4793f21bbc76e95ca7cf", null ],
    [ "ASerialLdd2_SendBlock_METHOD_ENABLED", "_a_serial_ldd2_8h.html#ga473316fdf4995cf5d1ecac85c658e5ed", null ],
    [ "BREAK_DETECTED", "_a_serial_ldd2_8h.html#ga617e6f524bf659f58012c8f0248004e5", null ],
    [ "ENABLE_TX_COMPLETE", "_a_serial_ldd2_8h.html#gac0fc7ebba74ca47c17389980225ddf48", null ],
    [ "ENABLED_TX_INT", "_a_serial_ldd2_8h.html#gab05896dbf11eed7f4078978e7287669d", null ],
    [ "TX_COMPLETED", "_a_serial_ldd2_8h.html#ga1f79d891cf81d9f65cccd3a0ab84b1ee", null ],
    [ "ASerialLdd2_TDeviceDataPtr", "_a_serial_ldd2_8h.html#ga2484df348f7d69cde065232de2522016", null ],
    [ "ASerialLdd2_GetError", "_a_serial_ldd2_8h.html#gafab1fb38c1ca4d64933a973a271ad7b0", null ],
    [ "ASerialLdd2_Init", "_a_serial_ldd2_8h.html#gaa0cd7e49c9c5deb19ce7f9ece16231c3", null ],
    [ "ASerialLdd2_ReceiveBlock", "_a_serial_ldd2_8h.html#gaf41a4ccffe5f5791cbc9b6e6e912962d", null ],
    [ "ASerialLdd2_SendBlock", "_a_serial_ldd2_8h.html#gabd167598efd957d04eb9bdd2e51ae673", null ],
    [ "PE_ISR", "_a_serial_ldd2_8h.html#ga8de88a30826abcdb10eeab68cc30bb09", null ]
];