var _motor_8h =
[
    [ "Motor_PERIOD_VALUE", "_motor_8h.html#ga88aa304bc8968efed2062d1cbb95b52d", null ],
    [ "Motor_PERIOD_VALUE_HIGH", "_motor_8h.html#ga3be4c5b515788d6f2526f48c6fff3897", null ],
    [ "Motor_SetDutyMS", "_motor_8h.html#gac110f67eed20a9205e730c82d39b7927", null ],
    [ "Motor_SetDutyUS", "_motor_8h.html#ga9e1e2921348e070281e32aea2ced9548", null ],
    [ "Motor_SetRatio16", "_motor_8h.html#ga60731ec82a528d7f146b56b1db397e20", null ]
];