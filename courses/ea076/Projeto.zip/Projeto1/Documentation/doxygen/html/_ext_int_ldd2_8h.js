var _ext_int_ldd2_8h =
[
    [ "ExtIntLdd2_DeviceData", "_ext_int_ldd2_8h.html#ga36ae509b2904f0733372b8e6ce00d57a", null ],
    [ "ExtIntLdd2_GetVal_METHOD_ENABLED", "_ext_int_ldd2_8h.html#ga7aba8514c16d97e710e7e336d51a4912", null ],
    [ "ExtIntLdd2_Init_METHOD_ENABLED", "_ext_int_ldd2_8h.html#ga3349fc52e8b5334f12efad50c5a6ac08", null ],
    [ "ExtIntLdd2_OnInterrupt_EVENT_ENABLED", "_ext_int_ldd2_8h.html#gaec5c008f62c410082fc37816139ab1f8", null ],
    [ "ExtIntLdd2_PIN_INDEX", "_ext_int_ldd2_8h.html#ga33ac82a1b934fd52908e8d31770c9983", null ],
    [ "ExtIntLdd2_PIN_MASK", "_ext_int_ldd2_8h.html#ga1c8476c9256c3bd4a5065c13a03481a2", null ],
    [ "ExtIntLdd2_PRPH_BASE_ADDRESS", "_ext_int_ldd2_8h.html#gab6819b38a0d234a7cfb5a86816b8d379", null ],
    [ "ExtIntLdd2_GetVal", "_ext_int_ldd2_8h.html#ga1a934e0fb480b3596d9b57963fd974d3", null ],
    [ "ExtIntLdd2_Init", "_ext_int_ldd2_8h.html#ga633f6e55098bd97e0801091d4981fc98", null ],
    [ "ExtIntLdd2_Interrupt", "_ext_int_ldd2_8h.html#ga374b6255e964dbd64f42197e1619ff01", null ]
];