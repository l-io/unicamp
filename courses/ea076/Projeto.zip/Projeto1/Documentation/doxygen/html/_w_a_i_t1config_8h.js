var _w_a_i_t1config_8h =
[
    [ "WAIT1_CONFIG_USE_CYCLE_COUNTER", "_w_a_i_t1config_8h.html#ac188ece74a79141a69f1178b8cf7f5f9", null ],
    [ "WAIT1_CONFIG_USE_RTOS_WAIT", "_w_a_i_t1config_8h.html#adf35d13c41c6b313ac7e82694657b929", null ]
];