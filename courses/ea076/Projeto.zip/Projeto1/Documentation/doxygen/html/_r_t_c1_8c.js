var _r_t_c1_8c =
[
    [ "RTC1_TDeviceDataPtr", "_r_t_c1_8c.html#gae1dda9bbc5f3626dcc3df64cb57a2984", null ],
    [ "PE_ISR", "_r_t_c1_8c.html#gad10e63c95cadae5f5b9bd1db4f857477", null ],
    [ "PE_ISR", "_r_t_c1_8c.html#ga15e68e29f9659063d40fb03dbf1f8f25", null ],
    [ "RTC1_GetTime", "_r_t_c1_8c.html#gaeed73f4c93bfd44f15170c28028c81fb", null ],
    [ "RTC1_Init", "_r_t_c1_8c.html#ga844f34d73a2540c6cd99df66b247dd49", null ],
    [ "RTC1_SetTime", "_r_t_c1_8c.html#ga91540e2cd845981f45f915884360d1fa", null ]
];