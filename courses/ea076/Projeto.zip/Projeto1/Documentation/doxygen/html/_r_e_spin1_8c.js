var _r_e_spin1_8c =
[
    [ "RESpin1_TDeviceDataPtr", "_r_e_spin1_8c.html#ga31661e5a74665999172b0905b36944b8", null ],
    [ "RESpin1_ClrVal", "_r_e_spin1_8c.html#gad24841dc21c57ce54ffbba3e5a3216cb", null ],
    [ "RESpin1_Deinit", "_r_e_spin1_8c.html#ga7edb8fcc59bddb17fe856a6ed35b7593", null ],
    [ "RESpin1_GetVal", "_r_e_spin1_8c.html#ga995729460ad08809e900bea6b06f3221", null ],
    [ "RESpin1_Init", "_r_e_spin1_8c.html#ga7c5d5e9f216cfae97ad0bf2277c67b0c", null ],
    [ "RESpin1_PutVal", "_r_e_spin1_8c.html#gae6ff9d41155badfd53caf80d53871bc9", null ],
    [ "RESpin1_SetVal", "_r_e_spin1_8c.html#ga56059e6eac36e66cca05b7046708022c", null ]
];