var _r_e_spin1_8h =
[
    [ "RESpin1_ClrVal_METHOD_ENABLED", "_r_e_spin1_8h.html#gad8d500116bb9ef66e5e2f2ee4ab2e7fd", null ],
    [ "RESpin1_Deinit_METHOD_ENABLED", "_r_e_spin1_8h.html#ga6203a1e52d0c46871b009a659d326b5e", null ],
    [ "RESpin1_GetVal_METHOD_ENABLED", "_r_e_spin1_8h.html#ga10acf9ef548ea8dc5db50f9170d4724b", null ],
    [ "RESpin1_Init_METHOD_ENABLED", "_r_e_spin1_8h.html#gab85383719acd47c896ab8760ae1f85fe", null ],
    [ "RESpin1_MODULE_BASE_ADDRESS", "_r_e_spin1_8h.html#ga834aeece72ce0f0efe2ddde37b36f7da", null ],
    [ "RESpin1_PORT_MASK", "_r_e_spin1_8h.html#ga08af8c2b6c78f6d96412b231db22d9f6", null ],
    [ "RESpin1_PORTCONTROL_BASE_ADDRESS", "_r_e_spin1_8h.html#ga312f305c9cc7dec36f7452335e8732a4", null ],
    [ "RESpin1_PRPH_BASE_ADDRESS", "_r_e_spin1_8h.html#ga0f96a5f8736290b2dbf02d3ef573ee97", null ],
    [ "RESpin1_PutVal_METHOD_ENABLED", "_r_e_spin1_8h.html#ga07094b9ac2b1f79c1d46fd86bd4db200", null ],
    [ "RESpin1_SetVal_METHOD_ENABLED", "_r_e_spin1_8h.html#ga42de400dcaafcd9629394d15816924d6", null ],
    [ "RESpin1_ClrVal", "_r_e_spin1_8h.html#gad24841dc21c57ce54ffbba3e5a3216cb", null ],
    [ "RESpin1_Deinit", "_r_e_spin1_8h.html#ga7edb8fcc59bddb17fe856a6ed35b7593", null ],
    [ "RESpin1_GetVal", "_r_e_spin1_8h.html#ga995729460ad08809e900bea6b06f3221", null ],
    [ "RESpin1_Init", "_r_e_spin1_8h.html#ga7c5d5e9f216cfae97ad0bf2277c67b0c", null ],
    [ "RESpin1_PutVal", "_r_e_spin1_8h.html#gae6ff9d41155badfd53caf80d53871bc9", null ],
    [ "RESpin1_SetVal", "_r_e_spin1_8h.html#ga56059e6eac36e66cca05b7046708022c", null ]
];