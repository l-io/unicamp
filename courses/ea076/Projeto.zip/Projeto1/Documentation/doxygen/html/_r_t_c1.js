var _r_t_c1 =
[
    [ "Component Settings", "_r_t_c1_settings.html", null ],
    [ "Registers Initialization Overview", "_r_t_c1_regs_overview.html", null ],
    [ "Register Initialization Details", "_r_t_c1_regs_details.html", null ]
];