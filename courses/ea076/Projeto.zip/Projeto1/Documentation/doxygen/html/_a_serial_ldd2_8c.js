var _a_serial_ldd2_8c =
[
    [ "AVAILABLE_EVENTS_MASK", "_a_serial_ldd2_8c.html#ga5f04a8830cd52a3ffa1678d113f31aee", null ],
    [ "ASerialLdd2_GetError", "_a_serial_ldd2_8c.html#gafab1fb38c1ca4d64933a973a271ad7b0", null ],
    [ "ASerialLdd2_Init", "_a_serial_ldd2_8c.html#gaa0cd7e49c9c5deb19ce7f9ece16231c3", null ],
    [ "ASerialLdd2_ReceiveBlock", "_a_serial_ldd2_8c.html#gaf41a4ccffe5f5791cbc9b6e6e912962d", null ],
    [ "ASerialLdd2_SendBlock", "_a_serial_ldd2_8c.html#gabd167598efd957d04eb9bdd2e51ae673", null ],
    [ "PE_ISR", "_a_serial_ldd2_8c.html#ga8de88a30826abcdb10eeab68cc30bb09", null ]
];