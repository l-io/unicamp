var _d_t_8h =
[
    [ "DT_ClrVal", "_d_t_8h.html#gaf64b805d907e099246d76c901d4fed10", null ],
    [ "DT_GetVal", "_d_t_8h.html#ga9155677346e8dc6d1dc99ef84e68ffd6", null ],
    [ "DT_PutVal", "_d_t_8h.html#ga69177c75f1ce4158d69be43ca73e1769", null ],
    [ "DT_SetDir", "_d_t_8h.html#ga55676f04f2f90205870981f6ad965ee6", null ],
    [ "DT_SetVal", "_d_t_8h.html#gabe9d6fe928b579ad2968e873ed90041e", null ]
];