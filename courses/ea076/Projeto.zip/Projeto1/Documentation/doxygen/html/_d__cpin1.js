var _d__cpin1 =
[
    [ "Component Settings", "_d__cpin1_settings.html", null ],
    [ "Registers Initialization Overview", "_d__cpin1_regs_overview.html", null ],
    [ "Register Initialization Details", "_d__cpin1_regs_details.html", null ]
];