var _a_serial_ldd1 =
[
    [ "Component Settings", "_a_serial_ldd1_settings.html", null ],
    [ "Registers Initialization Overview", "_a_serial_ldd1_regs_overview.html", null ],
    [ "Register Initialization Details", "_a_serial_ldd1_regs_details.html", null ]
];