var _a_serial_ldd1_8c =
[
    [ "AVAILABLE_EVENTS_MASK", "_a_serial_ldd1_8c.html#ga5f04a8830cd52a3ffa1678d113f31aee", null ],
    [ "ASerialLdd1_GetError", "_a_serial_ldd1_8c.html#gaac860ccc68e9f89fb25d97ae0c56bd87", null ],
    [ "ASerialLdd1_Init", "_a_serial_ldd1_8c.html#ga72a2988ac3b4e592eb9dd9c9cf0db38f", null ],
    [ "ASerialLdd1_ReceiveBlock", "_a_serial_ldd1_8c.html#gad445e8cc518c6e88fc212bd6d4e06490", null ],
    [ "ASerialLdd1_SendBlock", "_a_serial_ldd1_8c.html#gad73f06e0eda26a76d0ec611a50e16b1d", null ],
    [ "PE_ISR", "_a_serial_ldd1_8c.html#gaef4af12ca5f10beafaceb800c3c7d40c", null ]
];