var _r_e_spin1 =
[
    [ "Component Settings", "_r_e_spin1_settings.html", null ],
    [ "Registers Initialization Overview", "_r_e_spin1_regs_overview.html", null ],
    [ "Register Initialization Details", "_r_e_spin1_regs_details.html", null ]
];