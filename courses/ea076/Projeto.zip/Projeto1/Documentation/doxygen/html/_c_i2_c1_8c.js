var _c_i2_c1_8c =
[
    [ "ADDR_10", "_c_i2_c1_8c.html#ga69fee4ee235f21046f40402f682f17ec", null ],
    [ "ADDR_7", "_c_i2_c1_8c.html#ga3ff06ca6b55e8f7bc0145a36b4396eab", null ],
    [ "ADDR_COMPLETE", "_c_i2_c1_8c.html#ga57e558db0dbf2476a96f5ed90320498d", null ],
    [ "AVAILABLE_EVENTS_MASK", "_c_i2_c1_8c.html#ga5f04a8830cd52a3ffa1678d113f31aee", null ],
    [ "GENERAL_CALL", "_c_i2_c1_8c.html#ga2a33ff60ce60da98a6f16ea3d5ff806a", null ],
    [ "MASTER_IN_PROGRES", "_c_i2_c1_8c.html#ga75b75f2a24a05753b06756bdef0e704e", null ],
    [ "REP_ADDR_COMPLETE", "_c_i2_c1_8c.html#ga5c1fd7b880f8a808ae8da05aa588c39e", null ],
    [ "CI2C1_TDeviceDataPtr", "_c_i2_c1_8c.html#ga0092a4bf605362d2e0dd51f0a857e400", null ],
    [ "CI2C1_Deinit", "_c_i2_c1_8c.html#gabc03b5a52833888a39c4e7c7f84632c9", null ],
    [ "CI2C1_Init", "_c_i2_c1_8c.html#ga340c0a885f1e994269dd5f33fc616f32", null ],
    [ "CI2C1_MasterReceiveBlock", "_c_i2_c1_8c.html#ga361e50c9c40b74cdd1d37f9729d1e4dd", null ],
    [ "CI2C1_MasterSendBlock", "_c_i2_c1_8c.html#gaa461c589e2573dab219dae622c1f9ea4", null ],
    [ "CI2C1_SelectSlaveDevice", "_c_i2_c1_8c.html#gaab2f3efe50ee5b9aeebb3bc34a010137", null ],
    [ "PE_ISR", "_c_i2_c1_8c.html#ga45d62347cf6ec11bd2f79fcfa621b448", null ]
];