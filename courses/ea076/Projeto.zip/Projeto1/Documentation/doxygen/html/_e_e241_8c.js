var _e_e241_8c =
[
    [ "EE241_BANK_0", "_e_e241_8c.html#ga9226f0b77a422d7ca0ca9e81605904ee", null ],
    [ "EE241_BANK_1", "_e_e241_8c.html#gaba8ed89063d584c4b368c5314b769d83", null ],
    [ "EE241_CTRL_ADDR", "_e_e241_8c.html#ga7851878a57a010307c3ff8b85001b8f8", null ],
    [ "EE241_CTRL_BYTE", "_e_e241_8c.html#ga8ab0312edca14b07d9d0fbe4e5a22298", null ],
    [ "EE241_CTRL_NBL", "_e_e241_8c.html#gaa30882b7dd52d195d9b682f7af6628ec", null ],
    [ "EE241_DEVICE_ADDR", "_e_e241_8c.html#gac7ed2f4a4c0f7fa0707be1c7bbaca3fa", null ],
    [ "EE241_I2CAddress", "_e_e241_8c.html#gac379aa2a833544e88009bed0e7eefb86", null ],
    [ "EE241_ReadBlock", "_e_e241_8c.html#ga80792b51a53bbd97de7dbcd3ff9d86cd", null ],
    [ "EE241_ReadByte", "_e_e241_8c.html#ga982afa9536b10db5a0764a56502e8f9c", null ],
    [ "EE241_WriteBlock", "_e_e241_8c.html#gac6f295c10b0784f21e97ae7456835787", null ],
    [ "EE241_WriteBlockPage", "_e_e241_8c.html#ga5d97e5f8f3f54b1bfa4ae79ca4fd87c2", null ],
    [ "EE241_WriteByte", "_e_e241_8c.html#ga1070e81c28997395bd8de6a0a8b995be", null ]
];