var _s_c_k_8h =
[
    [ "SCK_ClrVal", "_s_c_k_8h.html#ga70194e74087f88bc83a239697d647c76", null ],
    [ "SCK_GetVal", "_s_c_k_8h.html#gacf52ce2362affbf2b862cc7a4bac68f3", null ],
    [ "SCK_PutVal", "_s_c_k_8h.html#gacba0f7b683eb3ebe4f00b86412536081", null ],
    [ "SCK_SetDir", "_s_c_k_8h.html#gac11b2920eab055b4b6be3cf6635603f0", null ],
    [ "SCK_SetVal", "_s_c_k_8h.html#ga4288d7390cba9bfd94f8e096001d307b", null ]
];