var _ext_int_ldd3 =
[
    [ "Component Settings", "_ext_int_ldd3_settings.html", null ],
    [ "Registers Initialization Overview", "_ext_int_ldd3_regs_overview.html", null ],
    [ "Register Initialization Details", "_ext_int_ldd3_regs_details.html", null ]
];