var _ext_int_ldd1_8c =
[
    [ "ExtIntLdd1_TDeviceDataPtr", "_ext_int_ldd1_8c.html#ga20bbc2032afbec34a11c7ebc34f84beb", null ],
    [ "ExtIntLdd1_GetVal", "_ext_int_ldd1_8c.html#ga29b8b12dae6b04dd5bfe8d4a24625da1", null ],
    [ "ExtIntLdd1_Init", "_ext_int_ldd1_8c.html#gaa1da311f89f9c2ebb94b7c5e7817767e", null ],
    [ "ExtIntLdd1_Interrupt", "_ext_int_ldd1_8c.html#gab2a1f2dbac838ce3d0441149175ec899", null ]
];