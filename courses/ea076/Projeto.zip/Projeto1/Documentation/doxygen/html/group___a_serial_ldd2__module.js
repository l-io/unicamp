var group___a_serial_ldd2__module =
[
    [ "ASerialLdd2_TDeviceData", "struct_a_serial_ldd2___t_device_data.html", [
      [ "ErrFlag", "struct_a_serial_ldd2___t_device_data.html#a1021f1662a4bc2bc7a9320dc212926e0", null ],
      [ "InpDataNumReq", "struct_a_serial_ldd2___t_device_data.html#ae6ceada79f32288b9d488088ea56bf36", null ],
      [ "InpDataPtr", "struct_a_serial_ldd2___t_device_data.html#ae7d8edc8b9d60f3b627bc0549585de6c", null ],
      [ "InpRecvDataNum", "struct_a_serial_ldd2___t_device_data.html#a551da007a82d4fd4e26ea72007112f46", null ],
      [ "OutDataNumReq", "struct_a_serial_ldd2___t_device_data.html#ac460a80b8506535c36fa730e3a61283d", null ],
      [ "OutDataPtr", "struct_a_serial_ldd2___t_device_data.html#ab4427d30f2614d2947ac957aa5eb9165", null ],
      [ "OutSentDataNum", "struct_a_serial_ldd2___t_device_data.html#a80df4c32d72ab149e6dbfb99b41c14f2", null ],
      [ "SerFlag", "struct_a_serial_ldd2___t_device_data.html#a3a23d8d86c35f325643a62974866594f", null ],
      [ "UserDataPtr", "struct_a_serial_ldd2___t_device_data.html#a5845eb75d51c879a652b884f6c71e8a3", null ]
    ] ],
    [ "ASerialLdd2_GetError_METHOD_ENABLED", "group___a_serial_ldd2__module.html#gad0d7256dc7800d335b9bb2122ae19459", null ],
    [ "ASerialLdd2_Init_METHOD_ENABLED", "group___a_serial_ldd2__module.html#ga0733c5676cb9059befd74a42eec355a1", null ],
    [ "ASerialLdd2_OnBlockReceived_EVENT_ENABLED", "group___a_serial_ldd2__module.html#ga1de13d2017cc0ef844acf2c461975589", null ],
    [ "ASerialLdd2_OnBlockSent_EVENT_ENABLED", "group___a_serial_ldd2__module.html#ga7dfcea605c62f020478dd3d4cbf9beb1", null ],
    [ "ASerialLdd2_OnBreak_EVENT_ENABLED", "group___a_serial_ldd2__module.html#ga975445b42dc0a4fc37d8683c75c73287", null ],
    [ "ASerialLdd2_OnError_EVENT_ENABLED", "group___a_serial_ldd2__module.html#gadba446a2ac10bec7ef67f2dae167bc86", null ],
    [ "ASerialLdd2_PRPH_BASE_ADDRESS", "group___a_serial_ldd2__module.html#ga0b40933a9f68fae4f6112ed9a6cfd9ef", null ],
    [ "ASerialLdd2_ReceiveBlock_METHOD_ENABLED", "group___a_serial_ldd2__module.html#gada8358a92a4e4793f21bbc76e95ca7cf", null ],
    [ "ASerialLdd2_SendBlock_METHOD_ENABLED", "group___a_serial_ldd2__module.html#ga473316fdf4995cf5d1ecac85c658e5ed", null ],
    [ "AVAILABLE_EVENTS_MASK", "group___a_serial_ldd2__module.html#ga5f04a8830cd52a3ffa1678d113f31aee", null ],
    [ "BREAK_DETECTED", "group___a_serial_ldd2__module.html#ga617e6f524bf659f58012c8f0248004e5", null ],
    [ "ENABLE_TX_COMPLETE", "group___a_serial_ldd2__module.html#gac0fc7ebba74ca47c17389980225ddf48", null ],
    [ "ENABLED_TX_INT", "group___a_serial_ldd2__module.html#gab05896dbf11eed7f4078978e7287669d", null ],
    [ "TX_COMPLETED", "group___a_serial_ldd2__module.html#ga1f79d891cf81d9f65cccd3a0ab84b1ee", null ],
    [ "ASerialLdd2_TDeviceDataPtr", "group___a_serial_ldd2__module.html#ga2484df348f7d69cde065232de2522016", null ],
    [ "ASerialLdd2_GetError", "group___a_serial_ldd2__module.html#gafab1fb38c1ca4d64933a973a271ad7b0", null ],
    [ "ASerialLdd2_Init", "group___a_serial_ldd2__module.html#gaa0cd7e49c9c5deb19ce7f9ece16231c3", null ],
    [ "ASerialLdd2_ReceiveBlock", "group___a_serial_ldd2__module.html#gaf41a4ccffe5f5791cbc9b6e6e912962d", null ],
    [ "ASerialLdd2_SendBlock", "group___a_serial_ldd2__module.html#gabd167598efd957d04eb9bdd2e51ae673", null ]
];