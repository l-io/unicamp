var _adc_ldd1 =
[
    [ "Component Settings", "_adc_ldd1_settings.html", null ],
    [ "Registers Initialization Overview", "_adc_ldd1_regs_overview.html", null ],
    [ "Register Initialization Details", "_adc_ldd1_regs_details.html", null ]
];