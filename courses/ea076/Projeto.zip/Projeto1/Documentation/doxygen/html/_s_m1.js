var _s_m1 =
[
    [ "Component Settings", "_s_m1_settings.html", null ],
    [ "Registers Initialization Overview", "_s_m1_regs_overview.html", null ],
    [ "Register Initialization Details", "_s_m1_regs_details.html", null ]
];