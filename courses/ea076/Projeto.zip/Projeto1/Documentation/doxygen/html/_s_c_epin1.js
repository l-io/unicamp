var _s_c_epin1 =
[
    [ "Component Settings", "_s_c_epin1_settings.html", null ],
    [ "Registers Initialization Overview", "_s_c_epin1_regs_overview.html", null ],
    [ "Register Initialization Details", "_s_c_epin1_regs_details.html", null ]
];