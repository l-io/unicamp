var _t_u1_8c =
[
    [ "AVAILABLE_PIN_MASK", "_t_u1_8c.html#gaae26cc68396d232c9dd6aed25157fe4c", null ],
    [ "LAST_CHANNEL", "_t_u1_8c.html#ga23dbf3ce1b12c52cb0db3c47845a3fef", null ],
    [ "TU1_TDeviceDataPtr", "_t_u1_8c.html#ga992897b60934aa5b8d6edb262c3bba55", null ],
    [ "TU1_GetCounterValue", "_t_u1_8c.html#ga1c2dce8338fb8784787fca8a8162ddbc", null ],
    [ "TU1_GetOffsetTicks", "_t_u1_8c.html#ga92c04b5447fde657da71680968acd784", null ],
    [ "TU1_GetPeriodTicks", "_t_u1_8c.html#gaa378924b104d5f8423920b110e8941e9", null ],
    [ "TU1_Init", "_t_u1_8c.html#ga9bfbdf45fe9128c8d9e4245e3480d6da", null ],
    [ "TU1_SelectOutputAction", "_t_u1_8c.html#ga69e314f91fe2ea96524ce0c389505b6b", null ],
    [ "TU1_SetOffsetTicks", "_t_u1_8c.html#gabc1056f77dad3dc9f11ccb4c2f3a9b47", null ]
];