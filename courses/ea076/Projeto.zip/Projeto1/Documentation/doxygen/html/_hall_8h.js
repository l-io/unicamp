var _hall_8h =
[
    [ "Hall_CHANNEL_COUNT", "_hall_8h.html#ga9dd5ba2c42ff2976fa77b1bd7198b06d", null ],
    [ "Hall_SAMPLE_GROUP_SIZE", "_hall_8h.html#ga6196ea897b9f73577f6422745ae2454b", null ],
    [ "AdcLdd1_OnMeasurementComplete", "_hall_8h.html#ga4776d32af94d7918f74bc7377ae5351f", null ],
    [ "Hall_Calibrate", "_hall_8h.html#ga142267c7e5e1bd8a44f5db161ea8760e", null ],
    [ "Hall_GetValue16", "_hall_8h.html#gaf190839a346b0b30ff8d4589a46668ed", null ],
    [ "Hall_HWEnDi", "_hall_8h.html#ga98bc046d54bf3d2e9f9ca742595ef4c0", null ],
    [ "Hall_Init", "_hall_8h.html#ga31f361639ad4baef8902a3529a4c71fb", null ],
    [ "Hall_Measure", "_hall_8h.html#ga475a11b4232dd75e9aea088f7ab62034", null ]
];