var _c_i2_c1 =
[
    [ "Component Settings", "_c_i2_c1_settings.html", null ],
    [ "Registers Initialization Overview", "_c_i2_c1_regs_overview.html", null ],
    [ "Register Initialization Details", "_c_i2_c1_regs_details.html", null ]
];