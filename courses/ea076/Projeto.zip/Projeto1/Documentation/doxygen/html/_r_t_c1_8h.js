var _r_t_c1_8h =
[
    [ "RTC1_DeviceData", "_r_t_c1_8h.html#gaf408ea7389b715a7993fe1abc830ee7d", null ],
    [ "RTC1_GetTime_METHOD_ENABLED", "_r_t_c1_8h.html#ga68cfd5878ced2231279a5ec9cec48d05", null ],
    [ "RTC1_Init_METHOD_ENABLED", "_r_t_c1_8h.html#gae9f49e013757febe26a91d3d403ac89f", null ],
    [ "RTC1_INTERRUPT_MODE", "_r_t_c1_8h.html#ga9c7b6d1f2ca6e519921030d7157d1c4e", null ],
    [ "RTC1_OnSecond_EVENT_ENABLED", "_r_t_c1_8h.html#ga0a843082919e5a384e4f7b91de31f823", null ],
    [ "RTC1_PRPH_BASE_ADDRESS", "_r_t_c1_8h.html#gae43d8732a649441401c7d94c679f324b", null ],
    [ "RTC1_SetTime_METHOD_ENABLED", "_r_t_c1_8h.html#ga734e8dc20145b950b4556deab3a14218", null ],
    [ "PE_ISR", "_r_t_c1_8h.html#gad10e63c95cadae5f5b9bd1db4f857477", null ],
    [ "PE_ISR", "_r_t_c1_8h.html#ga15e68e29f9659063d40fb03dbf1f8f25", null ],
    [ "RTC1_GetTime", "_r_t_c1_8h.html#gaeed73f4c93bfd44f15170c28028c81fb", null ],
    [ "RTC1_Init", "_r_t_c1_8h.html#ga844f34d73a2540c6cd99df66b247dd49", null ],
    [ "RTC1_SetTime", "_r_t_c1_8h.html#ga91540e2cd845981f45f915884360d1fa", null ]
];