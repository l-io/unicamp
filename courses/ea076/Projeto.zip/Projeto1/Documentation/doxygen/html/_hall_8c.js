var _hall_8c =
[
    [ "CALIBRATING", "_hall_8c.html#ga26c3762ed87f9dd7c55b86b162e8461f", null ],
    [ "CONTINUOUS", "_hall_8c.html#gacf80826c205230fbc6a84ab9c46ff9af", null ],
    [ "MEASURE", "_hall_8c.html#ga4691aeea76a4f3a3bdbff68ce5ab56a1", null ],
    [ "SINGLE", "_hall_8c.html#gaae597f206a8cf88b5a0593f39044b937", null ],
    [ "STOP", "_hall_8c.html#gae19b6bb2940d2fbe0a79852b070eeafd", null ],
    [ "AdcLdd1_OnMeasurementComplete", "_hall_8c.html#ga4776d32af94d7918f74bc7377ae5351f", null ],
    [ "Hall_Calibrate", "_hall_8c.html#ga142267c7e5e1bd8a44f5db161ea8760e", null ],
    [ "Hall_GetValue16", "_hall_8c.html#gaf190839a346b0b30ff8d4589a46668ed", null ],
    [ "Hall_HWEnDi", "_hall_8c.html#ga98bc046d54bf3d2e9f9ca742595ef4c0", null ],
    [ "Hall_Init", "_hall_8c.html#ga31f361639ad4baef8902a3529a4c71fb", null ],
    [ "Hall_Measure", "_hall_8c.html#ga475a11b4232dd75e9aea088f7ab62034", null ],
    [ "AdcLdd1_DeviceDataPtr", "_hall_8c.html#ga6a1ba182ca9bc85d625f7019e5dc2c65", null ],
    [ "Hall_OutV", "_hall_8c.html#ga748ebb2ce2ad6356fd6106f3f8d382de", null ]
];