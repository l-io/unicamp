var group___a_serial_ldd1__module =
[
    [ "ASerialLdd1_TDeviceData", "struct_a_serial_ldd1___t_device_data.html", [
      [ "ErrFlag", "struct_a_serial_ldd1___t_device_data.html#affbbfe6e7ba079ce255673d47d590070", null ],
      [ "InpDataNumReq", "struct_a_serial_ldd1___t_device_data.html#adef27888586bb5b013c747537f585ad4", null ],
      [ "InpDataPtr", "struct_a_serial_ldd1___t_device_data.html#ae08af57044e4ad054cddeff271e52826", null ],
      [ "InpRecvDataNum", "struct_a_serial_ldd1___t_device_data.html#ae54e8bc2a6f1560a186cf4921de12747", null ],
      [ "OutDataNumReq", "struct_a_serial_ldd1___t_device_data.html#a075ec547a9bd9c9e41181966a6b9b203", null ],
      [ "OutDataPtr", "struct_a_serial_ldd1___t_device_data.html#a2a004530c79852f3a438dd1deda07c3a", null ],
      [ "OutSentDataNum", "struct_a_serial_ldd1___t_device_data.html#a84390528474a595546a2fbefdd3a63fd", null ],
      [ "SerFlag", "struct_a_serial_ldd1___t_device_data.html#affb5a6a3a2d0c0dc54c04a66b2e1ada0", null ],
      [ "UserDataPtr", "struct_a_serial_ldd1___t_device_data.html#a7fed00148f2be816d5e81f693ced1df7", null ]
    ] ],
    [ "ASerialLdd1_GetError_METHOD_ENABLED", "group___a_serial_ldd1__module.html#gab680be05b2b7c712d928dbd5714e76f3", null ],
    [ "ASerialLdd1_Init_METHOD_ENABLED", "group___a_serial_ldd1__module.html#ga84f54fa4124bc3dd49cf50bcc270179e", null ],
    [ "ASerialLdd1_OnBlockReceived_EVENT_ENABLED", "group___a_serial_ldd1__module.html#ga72f80f8a03f6e282f98fa48bbace1b26", null ],
    [ "ASerialLdd1_OnBlockSent_EVENT_ENABLED", "group___a_serial_ldd1__module.html#gaa7051315c6d66d9dad5981181abbbb2a", null ],
    [ "ASerialLdd1_OnBreak_EVENT_ENABLED", "group___a_serial_ldd1__module.html#gaa1fbbf5b726d5b064e6f772a364572c8", null ],
    [ "ASerialLdd1_OnError_EVENT_ENABLED", "group___a_serial_ldd1__module.html#gab39b2ceda501dc0190b56ef407291fc5", null ],
    [ "ASerialLdd1_PRPH_BASE_ADDRESS", "group___a_serial_ldd1__module.html#gad9f8e308ce0b459724fa9063778226f3", null ],
    [ "ASerialLdd1_ReceiveBlock_METHOD_ENABLED", "group___a_serial_ldd1__module.html#ga1aee05f3a9c0f5ae70acda61f9168dec", null ],
    [ "ASerialLdd1_SendBlock_METHOD_ENABLED", "group___a_serial_ldd1__module.html#ga509640fb9027c94e88c56ac41d695f7b", null ],
    [ "AVAILABLE_EVENTS_MASK", "group___a_serial_ldd1__module.html#ga5f04a8830cd52a3ffa1678d113f31aee", null ],
    [ "BREAK_DETECTED", "group___a_serial_ldd1__module.html#ga617e6f524bf659f58012c8f0248004e5", null ],
    [ "ENABLE_TX_COMPLETE", "group___a_serial_ldd1__module.html#gac0fc7ebba74ca47c17389980225ddf48", null ],
    [ "ENABLED_TX_INT", "group___a_serial_ldd1__module.html#gab05896dbf11eed7f4078978e7287669d", null ],
    [ "TX_COMPLETED", "group___a_serial_ldd1__module.html#ga1f79d891cf81d9f65cccd3a0ab84b1ee", null ],
    [ "ASerialLdd1_TDeviceDataPtr", "group___a_serial_ldd1__module.html#ga3d5a6f8c983c88c4447d8c30465a7d12", null ],
    [ "ASerialLdd1_GetError", "group___a_serial_ldd1__module.html#gaac860ccc68e9f89fb25d97ae0c56bd87", null ],
    [ "ASerialLdd1_Init", "group___a_serial_ldd1__module.html#ga72a2988ac3b4e592eb9dd9c9cf0db38f", null ],
    [ "ASerialLdd1_ReceiveBlock", "group___a_serial_ldd1__module.html#gad445e8cc518c6e88fc212bd6d4e06490", null ],
    [ "ASerialLdd1_SendBlock", "group___a_serial_ldd1__module.html#gad73f06e0eda26a76d0ec611a50e16b1d", null ]
];