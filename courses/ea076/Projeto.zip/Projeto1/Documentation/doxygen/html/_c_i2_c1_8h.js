var _c_i2_c1_8h =
[
    [ "CI2C1_Deinit_METHOD_ENABLED", "_c_i2_c1_8h.html#ga2fe8185cc1ea3a7c6fdf50bbfad3c63e", null ],
    [ "CI2C1_Init_METHOD_ENABLED", "_c_i2_c1_8h.html#ga83a864c8d29bf009b0b6189b85ba2fa0", null ],
    [ "CI2C1_MasterReceiveBlock_METHOD_ENABLED", "_c_i2_c1_8h.html#ga28260740b9fb573de8b99ed0f511f7d3", null ],
    [ "CI2C1_MasterSendBlock_METHOD_ENABLED", "_c_i2_c1_8h.html#gab08ca0aa4c713f4a6dbc8b43b62ce5ff", null ],
    [ "CI2C1_OnMasterBlockReceived_EVENT_ENABLED", "_c_i2_c1_8h.html#gac3def3fafffcb8531bceb42dfaad59e0", null ],
    [ "CI2C1_OnMasterBlockSent_EVENT_ENABLED", "_c_i2_c1_8h.html#gaec18f6acc3f5b2700a6df434d20ce4c8", null ],
    [ "CI2C1_PRPH_BASE_ADDRESS", "_c_i2_c1_8h.html#gac6c037a114fcc2c8b812d3e42612565a", null ],
    [ "CI2C1_SelectSlaveDevice_METHOD_ENABLED", "_c_i2_c1_8h.html#ga532ac47ee57c1cb958b474501f8c547d", null ],
    [ "CI2C1_Deinit", "_c_i2_c1_8h.html#gabc03b5a52833888a39c4e7c7f84632c9", null ],
    [ "CI2C1_Init", "_c_i2_c1_8h.html#ga340c0a885f1e994269dd5f33fc616f32", null ],
    [ "CI2C1_MasterReceiveBlock", "_c_i2_c1_8h.html#ga361e50c9c40b74cdd1d37f9729d1e4dd", null ],
    [ "CI2C1_MasterSendBlock", "_c_i2_c1_8h.html#gaa461c589e2573dab219dae622c1f9ea4", null ],
    [ "CI2C1_SelectSlaveDevice", "_c_i2_c1_8h.html#gaab2f3efe50ee5b9aeebb3bc34a010137", null ],
    [ "PE_ISR", "_c_i2_c1_8h.html#ga45d62347cf6ec11bd2f79fcfa621b448", null ]
];