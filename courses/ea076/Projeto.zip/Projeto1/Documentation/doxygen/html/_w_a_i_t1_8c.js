var _w_a_i_t1_8c =
[
    [ "__attribute__", "_w_a_i_t1_8c.html#ga0d401ca6ca297b5b7a450deed0c42b78", null ],
    [ "WAIT1_DeInit", "_w_a_i_t1_8c.html#ga8024b107f0d8d25c88974c6a709b1f88", null ],
    [ "WAIT1_Init", "_w_a_i_t1_8c.html#ga3bb855c4f83a70665404289e66b8f2a7", null ],
    [ "WAIT1_WaitCycles", "_w_a_i_t1_8c.html#ga2ef0c866b014b3f8bba49508c79a4c21", null ],
    [ "WAIT1_WaitLongCycles", "_w_a_i_t1_8c.html#gad800b2446f397d9524bf1780d2646a57", null ],
    [ "WAIT1_Waitms", "_w_a_i_t1_8c.html#ga04b03075f856862ff2bc4ff69825aeb6", null ]
];