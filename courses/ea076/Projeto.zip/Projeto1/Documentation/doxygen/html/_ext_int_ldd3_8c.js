var _ext_int_ldd3_8c =
[
    [ "ExtIntLdd3_TDeviceDataPtr", "_ext_int_ldd3_8c.html#gad010732e60ad8dcb9d6d7bb2ee24345a", null ],
    [ "ExtIntLdd3_GetVal", "_ext_int_ldd3_8c.html#gad9b02560a6a830ebf65878e8e99cff15", null ],
    [ "ExtIntLdd3_Init", "_ext_int_ldd3_8c.html#ga3328295fbd8c9ac73e05e54426de6f6f", null ],
    [ "ExtIntLdd3_Interrupt", "_ext_int_ldd3_8c.html#gab9f475bb7370acbfd845008d67c322de", null ]
];