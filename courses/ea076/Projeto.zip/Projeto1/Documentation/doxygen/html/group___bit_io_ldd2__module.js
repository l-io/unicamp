var group___bit_io_ldd2__module =
[
    [ "BitIoLdd2_TDeviceData", "struct_bit_io_ldd2___t_device_data.html", [
      [ "UserDataPtr", "struct_bit_io_ldd2___t_device_data.html#adce7b8d72c3e208db6a56b0bb10898ac", null ]
    ] ],
    [ "BitIoLdd2_ClrVal_METHOD_ENABLED", "group___bit_io_ldd2__module.html#ga2cde86d856f0965fb132127390551a0d", null ],
    [ "BitIoLdd2_DeviceData", "group___bit_io_ldd2__module.html#gaf2ef02c6b9a8451493963d7ae23c7574", null ],
    [ "BitIoLdd2_GetVal_METHOD_ENABLED", "group___bit_io_ldd2__module.html#ga5c2fdb6732a439c3cc2dc51ed3c9f593", null ],
    [ "BitIoLdd2_Init_METHOD_ENABLED", "group___bit_io_ldd2__module.html#gaff3f9c9cb38ac7244b796333afef0c82", null ],
    [ "BitIoLdd2_MODULE_BASE_ADDRESS", "group___bit_io_ldd2__module.html#gae34d8d80fda789aa770f3068a4c7dfc7", null ],
    [ "BitIoLdd2_PORT_MASK", "group___bit_io_ldd2__module.html#gad48bd98192a32c10a7458ae8991abcb7", null ],
    [ "BitIoLdd2_PORTCONTROL_BASE_ADDRESS", "group___bit_io_ldd2__module.html#ga4194c86be52355349ef034fd3322dabf", null ],
    [ "BitIoLdd2_PRPH_BASE_ADDRESS", "group___bit_io_ldd2__module.html#gae2c93f84ea59b52ac4e0b1eac3a8b47f", null ],
    [ "BitIoLdd2_PutVal_METHOD_ENABLED", "group___bit_io_ldd2__module.html#gaae37d2b18f37861246a3993a457b001c", null ],
    [ "BitIoLdd2_SetDir_METHOD_ENABLED", "group___bit_io_ldd2__module.html#gaf5aa80f7ef3c1e1b712ab279a1680b8d", null ],
    [ "BitIoLdd2_SetVal_METHOD_ENABLED", "group___bit_io_ldd2__module.html#ga47665ce2390398cfa5381c9174d38ec0", null ],
    [ "BitIoLdd2_ClrVal", "group___bit_io_ldd2__module.html#ga544e4e9c98ec5fa4934bcac68c17d303", null ],
    [ "BitIoLdd2_GetVal", "group___bit_io_ldd2__module.html#gab03a5a6cf33499000ac033b999a4f587", null ],
    [ "BitIoLdd2_Init", "group___bit_io_ldd2__module.html#ga553dbb392db7bc92230a019512a1e5ab", null ],
    [ "BitIoLdd2_PutVal", "group___bit_io_ldd2__module.html#gaacea30e307e59fc9acf65e01892ad75b", null ],
    [ "BitIoLdd2_SetDir", "group___bit_io_ldd2__module.html#gae53f42481739846a79c3574415330e07", null ],
    [ "BitIoLdd2_SetVal", "group___bit_io_ldd2__module.html#gaa2b2b2e4849f05c5454ca6eb6d88fe6d", null ]
];