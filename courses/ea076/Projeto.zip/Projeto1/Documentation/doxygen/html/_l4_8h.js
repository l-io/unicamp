var _l4_8h =
[
    [ "L4_ClrVal", "_l4_8h.html#gaacd145724b2463e0067714ee7bd62639", null ],
    [ "L4_GetVal", "_l4_8h.html#ga6c6aa9d587fd221cfb5d1916ed6f4dfa", null ],
    [ "L4_PutVal", "_l4_8h.html#ga2f4b388498592297aebe5534f2c357b0", null ],
    [ "L4_SetDir", "_l4_8h.html#gab713696860d4141b6974bb71004ce5e7", null ],
    [ "L4_SetInput", "_l4_8h.html#ga2164e1760db67080b69ba4615c0348eb", null ],
    [ "L4_SetOutput", "_l4_8h.html#ga045fe81414b287081e674a7151aba66c", null ],
    [ "L4_SetVal", "_l4_8h.html#ga63281e750090761860c87ee174d8ea82", null ]
];