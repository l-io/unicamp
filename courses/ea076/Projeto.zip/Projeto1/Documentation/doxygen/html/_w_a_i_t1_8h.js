var _w_a_i_t1_8h =
[
    [ "WAIT1_INSTR_CLOCK_HZ", "_w_a_i_t1_8h.html#gad719b8589ad1bf92a03ec94ce95c4804", null ],
    [ "WAIT1_NofCyclesMs", "_w_a_i_t1_8h.html#ga7e74874c42a8979fb279fc86d373b60a", null ],
    [ "WAIT1_NofCyclesNs", "_w_a_i_t1_8h.html#gaca73593e1131b4845062bd9ec4ee5cac", null ],
    [ "WAIT1_NofCyclesUs", "_w_a_i_t1_8h.html#ga7dabbdd9744304c62df945607fa13dcf", null ],
    [ "WAIT1_WAIT_C", "_w_a_i_t1_8h.html#ga9824395bc44b736ec5b29dd219ef8418", null ],
    [ "WAIT1_Waitns", "_w_a_i_t1_8h.html#ga69b0cc93f0910d7f8f238d3e7d43c2c3", null ],
    [ "WAIT1_WaitOSms", "_w_a_i_t1_8h.html#ga2691150b572fe622d361fb48539af70e", null ],
    [ "WAIT1_Waitus", "_w_a_i_t1_8h.html#ga3bad7338e555cbbbaa870ee3fe2db0f6", null ],
    [ "WAIT1_DeInit", "_w_a_i_t1_8h.html#ga8024b107f0d8d25c88974c6a709b1f88", null ],
    [ "WAIT1_Init", "_w_a_i_t1_8h.html#ga3bb855c4f83a70665404289e66b8f2a7", null ],
    [ "WAIT1_Wait100Cycles", "_w_a_i_t1_8h.html#gaa9a9a87e96edf43071b5f322cfa72333", null ],
    [ "WAIT1_Wait10Cycles", "_w_a_i_t1_8h.html#gaff67df7b318b8d5cf4555a24fe7c7f93", null ],
    [ "WAIT1_WaitCycles", "_w_a_i_t1_8h.html#ga2ef0c866b014b3f8bba49508c79a4c21", null ],
    [ "WAIT1_WaitLongCycles", "_w_a_i_t1_8h.html#gad800b2446f397d9524bf1780d2646a57", null ],
    [ "WAIT1_Waitms", "_w_a_i_t1_8h.html#ga04b03075f856862ff2bc4ff69825aeb6", null ]
];