var _adc_ldd1_8c =
[
    [ "AdcLdd1_AVAILABLE_CHANNEL0_31_PIN_MASK", "_adc_ldd1_8c.html#gae667536b042ed10bbf59a6ab655e2520", null ],
    [ "AdcLdd1_AVAILABLE_CHANNEL32_63_PIN_MASK", "_adc_ldd1_8c.html#ga76e2c2c848190a43f723097450d2bd44", null ],
    [ "AdcLdd1_AVAILABLE_TRIGGER_PIN_MASK", "_adc_ldd1_8c.html#ga9364f8d60a68e5f5546eb5bf87436569", null ],
    [ "AdcLdd1_AVAILABLE_VOLT_REF_PIN_MASK", "_adc_ldd1_8c.html#ga42c6c07d48741426405776dfc62732a6", null ],
    [ "AdcLdd1_TDeviceDataPtr", "_adc_ldd1_8c.html#gabc048953ad953bc16463d49d94832206", null ],
    [ "AdcLdd1_CancelMeasurement", "_adc_ldd1_8c.html#ga26924e7e4ca2c272140fbaf6ecf9c18d", null ],
    [ "AdcLdd1_CreateSampleGroup", "_adc_ldd1_8c.html#ga86203c058acad0397b653ce3a4a625a4", null ],
    [ "AdcLdd1_GetCalibrationResultStatus", "_adc_ldd1_8c.html#gaeec76afa5d4906636d7b7acd8a4008d3", null ],
    [ "AdcLdd1_GetMeasuredValues", "_adc_ldd1_8c.html#ga30f524b93639b958a529d6f91c41ce6d", null ],
    [ "AdcLdd1_GetMeasurementCompleteStatus", "_adc_ldd1_8c.html#ga4df44002c6ba3479f104deedd98b7e4e", null ],
    [ "AdcLdd1_Init", "_adc_ldd1_8c.html#gafdc37e93f468b5be237479085546273f", null ],
    [ "AdcLdd1_StartCalibration", "_adc_ldd1_8c.html#gab9d49b5f1a7ef34cde56046754ebb62a", null ],
    [ "AdcLdd1_StartSingleMeasurement", "_adc_ldd1_8c.html#ga00728ff1e652d8d8d778917ca27e37a1", null ],
    [ "PE_ISR", "_adc_ldd1_8c.html#ga563031e4594799f73a2a64dbdc65ea00", null ]
];