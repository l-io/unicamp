var _a_serial_ldd2 =
[
    [ "Component Settings", "_a_serial_ldd2_settings.html", null ],
    [ "Registers Initialization Overview", "_a_serial_ldd2_regs_overview.html", null ],
    [ "Register Initialization Details", "_a_serial_ldd2_regs_details.html", null ]
];