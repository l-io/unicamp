var _ext_int_ldd1 =
[
    [ "Component Settings", "_ext_int_ldd1_settings.html", null ],
    [ "Registers Initialization Overview", "_ext_int_ldd1_regs_overview.html", null ],
    [ "Register Initialization Details", "_ext_int_ldd1_regs_details.html", null ]
];