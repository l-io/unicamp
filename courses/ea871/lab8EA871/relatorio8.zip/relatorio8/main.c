/*
 * Roteiro 8
 * Monica Aoki Faria              RA:156787
 * Leonardo Rodrigues Marques     RA:178610
 */

#include "MKL25z4.h"
#include "derivative.h" /* include peripheral declarations */
#include "delay.h"
#include "lcd.h"
#include "uart.h"

int main(void)
{
	
	init_GPIO_LCD();
	init_LCD();
	init_UART0();
	
	clear_UART0();
	cursor_UART0();
	
	setpos_LCD(1,1); 
	putchar_LCD(48);
	putchar_LCD(48);
	putchar_LCD(58);
	putchar_LCD(48);
	putchar_LCD(48);
	putchar_LCD(58);
	putchar_LCD(48);
	putchar_LCD(48);
	putchar_LCD(58);
	putchar_LCD(48);
	putchar_LCD(48);
	
	cronometro();   	
	
	return 0;
}

void cronometro() {
	
	char c;
	char display = 0;
	char list = 0;
	char cs_unidade;
	char cs_dezena;
	char seg_unidade = 48;
	char seg_dezena = 48;
	char min_unidade = 48;
	char min_dezena = 48;
	char hora_unidade = 48;
	char hora_dezena = 48;
	char seg = 0;
	char min = 0;
	char horas = 0;
	char cs = 0;
	
	for(cs = 1; cs < 61; cs++){
		c = getchar_UART0();
		if(c == 's'){
			c = 0;
			while(c != 's'){
				while(!(UART0_S1 & UART0_S1_RDRF_MASK)) ; 		// se n�o est� vazio (Register Empty), espera 
				c = getchar_UART0();
			}
		}
		if(c == 'r'){
			setpos_LCD(1,1); 
			putchar_LCD(48);
			putchar_LCD(48);
			putchar_LCD(58);
			putchar_LCD(48);
			putchar_LCD(48);
			putchar_LCD(58);
			putchar_LCD(48);
			putchar_LCD(48);
			putchar_LCD(58);
			putchar_LCD(48);
			putchar_LCD(48);
			seg_unidade = 48;
			seg_dezena = 48;
			min_unidade = 48;
			min_dezena = 48;
			hora_unidade = 48;
			hora_dezena = 48;
			seg = 0;
			min = 0;
			horas = 0;
			cs = 0;
		}
		if(c == 'd'){
			display = !display;
		}
		if(c == 'l'){
			list = !list;
			clear_UART0();
			cursor_UART0();
		}
		if(c == 27){
			clear_UART0();
			clear_LCD();
			break;
		}
		delay(15000);
		setpos_LCD(1,1);
		cs_unidade = (cs%10) + 48;
		cs_dezena = (cs/10)%10 + 48;
		setpos_LCD(1,11); 
		putchar_LCD(cs_unidade);
		setpos_LCD(1,10); 
		putchar_LCD(cs_dezena);
		
		if(display == 1){
			if(list == 0){
				cursor_UART0();
			}
			putchar_UART0(hora_dezena);
			putchar_UART0(hora_unidade);
			putchar_UART0(':');
			putchar_UART0(min_dezena);
			putchar_UART0(min_unidade);
			putchar_UART0(':');
			putchar_UART0(seg_dezena);
			putchar_UART0(seg_unidade);
			putchar_UART0(':');
			putchar_UART0(cs_dezena);
			putchar_UART0(cs_unidade);
			if(list == 1){
				putchar_UART0('\n');
				putchar_UART0('\r');
			}
		}
		else{
			clear_UART0();
		}
		if(cs >= 59) {
			seg++;
			cs = 0;
			seg_unidade = (seg%10) + 48;
			seg_dezena = (seg/10)%10 + 48;
			
			setpos_LCD(1,8); 
			putchar_LCD(seg_unidade);
			setpos_LCD(1,7); 
			putchar_LCD(seg_dezena);
			setpos_LCD(1,11); 
			putchar_LCD(48);
			setpos_LCD(1,10); 
			putchar_LCD(48);
		}
		if(seg >= 60) {
			min++;
			seg = 0;
			min_unidade = (min%10) + 48;
			min_dezena = (min/10)%10 + 48;
			setpos_LCD(1,5); 
			putchar_LCD(min_unidade);
			setpos_LCD(1,4); 
			putchar_LCD(min_dezena);
			setpos_LCD(1,8); 
			putchar_LCD(48);
			setpos_LCD(1,7); 
			putchar_LCD(48);
		}
		if(min >= 59){
			horas++;
			min = 0;
			hora_unidade = (horas%10) + 48;
			hora_dezena = (horas/10)%10 + 48;
			setpos_LCD(1,2); 
			putchar_LCD(hora_unidade);
			setpos_LCD(1,1); 
			putchar_LCD(hora_dezena);
			setpos_LCD(1,5); 
			putchar_LCD(48);
			setpos_LCD(1,4); 
			putchar_LCD(48);
		}
		
	}
}

