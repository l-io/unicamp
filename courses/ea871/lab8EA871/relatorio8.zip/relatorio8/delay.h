/*
 * delay.h
 *
 *  Created on: Apr 13, 2018
 *      Author: ea871
 */

#ifndef DELAY_H_
#define DELAY_H_

void delay (int t);


#endif /* DELAY_H_ */
